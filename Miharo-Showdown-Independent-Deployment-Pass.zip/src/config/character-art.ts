/**
 * Character artwork registry.
 *
 * Approved artwork supplied by the owner, split from the master expression
 * sheets into one image per character state and served from the CDN.
 * This is the single source of truth for character/host imagery — components
 * never hardcode a URL.
 */
import type { CharacterState } from "./characters";
import type { AceAssetSlot } from "./ace";

import keaNeutral from "@/assets/characters/kea-neutral.png.asset.json";
import keaWinning from "@/assets/characters/kea-winning.png.asset.json";
import keaShocked from "@/assets/characters/kea-shocked.png.asset.json";
import keaDefeated from "@/assets/characters/kea-defeated.png.asset.json";
import kereruNeutral from "@/assets/characters/kereru-neutral.png.asset.json";
import kereruWinning from "@/assets/characters/kereru-winning.png.asset.json";
import kereruShocked from "@/assets/characters/kereru-shocked.png.asset.json";
import kereruDefeated from "@/assets/characters/kereru-defeated.png.asset.json";
import tuiNeutral from "@/assets/characters/tui-neutral.png.asset.json";
import tuiWinning from "@/assets/characters/tui-winning.png.asset.json";
import tuiShocked from "@/assets/characters/tui-shocked.png.asset.json";
import tuiDefeated from "@/assets/characters/tui-defeated.png.asset.json";
import piwakawakaNeutral from "@/assets/characters/piwakawaka-neutral.png.asset.json";
import piwakawakaWinning from "@/assets/characters/piwakawaka-winning.png.asset.json";
import piwakawakaShocked from "@/assets/characters/piwakawaka-shocked.png.asset.json";
import piwakawakaDefeated from "@/assets/characters/piwakawaka-defeated.png.asset.json";
import kiwiNeutral from "@/assets/characters/kiwi-neutral.png.asset.json";
import kiwiWinning from "@/assets/characters/kiwi-winning.png.asset.json";
import kiwiShocked from "@/assets/characters/kiwi-shocked.png.asset.json";
import kiwiDefeated from "@/assets/characters/kiwi-defeated.png.asset.json";
import korimakoNeutral from "@/assets/characters/korimako-neutral.png.asset.json";
import korimakoWinning from "@/assets/characters/korimako-winning.png.asset.json";
import korimakoShocked from "@/assets/characters/korimako-shocked.png.asset.json";
import korimakoDefeated from "@/assets/characters/korimako-defeated.png.asset.json";


export const CHARACTER_ART: Record<string, Record<CharacterState, string>> = {
  kea: {
    neutral: keaNeutral.url,
    winning: keaWinning.url,
    shocked: keaShocked.url,
    defeated: keaDefeated.url,
  },
  kereru: {
    neutral: kereruNeutral.url,
    winning: kereruWinning.url,
    shocked: kereruShocked.url,
    defeated: kereruDefeated.url,
  },
  tui: {
    neutral: tuiNeutral.url,
    winning: tuiWinning.url,
    shocked: tuiShocked.url,
    defeated: tuiDefeated.url,
  },
  piwakawaka: {
    neutral: piwakawakaNeutral.url,
    winning: piwakawakaWinning.url,
    shocked: piwakawakaShocked.url,
    defeated: piwakawakaDefeated.url,
  },
  kiwi: {
    neutral: kiwiNeutral.url,
    winning: kiwiWinning.url,
    shocked: kiwiShocked.url,
    defeated: kiwiDefeated.url,
  },
  korimako: {
    neutral: korimakoNeutral.url,
    winning: korimakoWinning.url,
    shocked: korimakoShocked.url,
    defeated: korimakoDefeated.url,
  },
};

/** Ace's four approved poses, mapped onto her stage slots. */
export const ACE_ART: Record<AceAssetSlot, string> = {
  idle: "/production/ace/welcome.webp",
  excited: "/production/ace/excited.webp",
  celebrating: "/production/ace/champion.webp",
  pointing: "/production/ace/presenting.webp",
  shocked: "/production/ace/shocked.webp",
  defeated: "/production/ace/shocked.webp",
};

export function characterArt(slug: string, state: CharacterState = "neutral") {
  return CHARACTER_ART[slug]?.[state] ?? null;
}

export function aceArt(slot: AceAssetSlot = "idle") {
  return ACE_ART[slot] ?? ACE_ART.idle;
}
